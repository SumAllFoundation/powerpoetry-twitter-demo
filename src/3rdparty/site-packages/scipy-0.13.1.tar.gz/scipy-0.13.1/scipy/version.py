
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.13.1'
version = '0.13.1'
full_version = '0.13.1'
git_revision = 'f0cff311a8f397ec525db019d6f4758f29b51882'
release = True

if not release:
    version = full_version
